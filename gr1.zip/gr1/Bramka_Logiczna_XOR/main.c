#include <stdio.h>

int main() {

    int a = 12, b = 25;
    printf("Wynik = %d", ((~a)&b) | (a&(~b)));

    return 0;
}
