#include <stdio.h>

int main()
{
    change(255);
    showBit(255,5);
}


void change (unsigned decimal_num)
{
    int c, result;

    for (c = 8; c >= 0; c--)
    {
        result = decimal_num >> c;

        if (result & 1)
            printf("1");
        else
            printf("0");
    }

    printf("\n");
}

void showBit(int temp, int n)
{
    int bit = (temp >> n) & 1U;
    printf("%d", bit);
}
